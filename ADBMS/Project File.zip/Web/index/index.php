<?php 

 include "../CommenLayouts/header.php";

 include "../CommenLayouts/navBar.php";

 include "../CommenLayouts/sideDrawer.php";

 include "../CommenLayouts/banner.php";

 include "../CommenLayouts/sideDrawerEnd.php";

 //include "../CommenLayouts/adPanel.php";

?>



<?php

include "searchItems.php";
include "hotOffers.php";
 
?>




<?php
include "js.php";
include "../CommenLayouts/footer.php";
?>