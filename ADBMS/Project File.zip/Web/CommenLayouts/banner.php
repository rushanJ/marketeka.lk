
		<div class="w3l_banner_nav_right">
			<section class="slider">
				<div class="flexslider">
					<ul class="slides">
						<li>
							<div class="w3l_banner_nav_right_banner1">
								<!--<h3>Register your <span>Shop</span> and help.</h3>-->
								<div class="more">
									<!--<a href="../seller" class="button--saqui button--round-l button--text-thick" data-text="Register">Seller Area</a>-->S
								</div>
							</div>
						</li>
						<li>
							<div class="w3l_banner_nav_right_banner2">
								<!--<h3>Register your <span>Shop</span> and help.</h3>-->
								<div class="more">
									<!--<a href="../seller" class="button--saqui button--round-l button--text-thick" data-text="Register">Seller Area</a>-->
								</div>
							</div>
						</li>
						<li>
							<div class="w3l_banner_nav_right_banner3">
								<!--<h3>Register your <span>Shop</span> and help.</h3>-->
								<div class="more">
									<!--<a href="../seller" class="button--saqui button--round-l button--text-thick" data-text="Register">Seller Area</a>-->
								</div>
							</div>
						</li>
						<li>
							<div class="w3l_banner_nav_right_banner4">
								<!--<h3>Register your <span>Shop</span> and help.</h3>-->
								<div class="more">
									<!--<a href="../seller" class="button--saqui button--round-l button--text-thick" data-text="Register">Seller Area</a>-->
								</div>
							</div>
						</li>
						<li>
							<div class="w3l_banner_nav_right_banner5">
								<!--<h3>Register your <span>Shop</span> and help.</h3>-->
								<div class="more">
									<!--<a href="../seller" class="button--saqui button--round-l button--text-thick" data-text="Register">Seller Area</a>-->
								</div>
							</div>
						</li>
						
						
						
						
						
						
					</ul>
				</div>
			</section>
			<!-- flexSlider -->
				<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" property="" />
				<script defer src="js/jquery.flexslider.js"></script>
				<script type="text/javascript">
				$(window).load(function(){
				  $('.flexslider').flexslider({
					animation: "slide",
					start: function(slider){
					  $('body').removeClass('loading');
					}
				  });
				});
			  </script>
			<!-- //flexSlider -->
		</div>
		<div class="clearfix"></div>
<!-- banner -->