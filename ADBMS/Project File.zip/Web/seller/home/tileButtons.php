<div class="w3-row-padding w3-margin-bottom ">

    <div class="w3-quarter">
      <div class="w3-container w3-red w3-padding-16 w3-panel w3-border w3-round-xlarge">
      <div class="w3-left"></div>
      
        <div class="w3-clear"></div>
        <h4><a>Items</a></h4>
      </div>
    </div>

    <div class="w3-quarter">
      <div class="w3-container w3-blue w3-padding-16 w3-panel w3-border w3-round-xlarge">
        <div class="w3-left"></div>
        
        <div class="w3-clear"></div>
        <h4>Customers</h4>
      </div>
    </div>

    <div class="w3-quarter">
      <div class="w3-container w3-teal w3-padding-16 w3-panel w3-border w3-round-xlarge">
        <div class="w3-left "></div>
        
        <div class="w3-clear"></div>
        <h4>New Orders</h4>
      </div>
    </div>

    <div class="w3-quarter">
      <div class="w3-container w3-orange w3-text-white w3-padding-16 w3-panel w3-border w3-round-xlarge">
        <div class="w3-left"></i></div>
        
        <div class="w3-clear"></div>
        <h4>Shipped Orders</h4>
      </div>
    </div>

  </div>