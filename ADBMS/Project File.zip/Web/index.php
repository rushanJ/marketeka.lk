<?php
header("Location: index"); /* Redirect browser */
exit();
?>