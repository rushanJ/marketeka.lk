<div class="top-brands"> 
		<div class="container">
			<h3>Hot Offers</h3>
			<div class="agile_top_brands_grids">
				<?php include "../php/hotDeals.php" ?>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>