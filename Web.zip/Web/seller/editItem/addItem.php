
<div class="w3-card-4">
  <div class="w3-container w3-flat-turquoise">
    <h2>Input Colors</h2>
  </div>
  <form class="w3-container" method="POST" action="../php/addItem.php" enctype="multipart/form-data">
    
    
  <?php
include "../php/getItem.php";
?>
    
    <button class="w3-btn w3-flat-turquoise w3-blue">Edit</button></p>
  </form>
</div>