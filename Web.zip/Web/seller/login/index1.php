
<div  >

<div class="w3-card-4 w3-margin w3-panel w3-padding-16 ">

<form action="../php/auth.php" method="post" class="w3-container" >
  
	<img src="../../images/loginLogo.png" alt="Avatar" style="width: 250px;padding-left:10%;" class="w3-round ">

  <div class="container ">
    <label for="uname"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" class='w3-input' name="userName" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" class='w3-input'  name="pass" required>
        
    <button type="submit" class="w3-button  w3-red">Login</button>
   
   
    
  </div> 
  </form>
 

  <div class="container" style="background-color:#f1f1f1">
    <a href="../register"><button type="button" >Register</button></a>
    <span class="psw">Forgot <a href="#">password?</a></span>
  </div>

  

</div>
</div>

