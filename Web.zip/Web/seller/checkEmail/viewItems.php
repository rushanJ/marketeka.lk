<div  style="margin: 10%">
<div class="w3-panel w3-card w3-padding-64 w3-margin">
<img src="../../images/mail.png" class="w3-round" alt="Norway"  style="width:20%;margin-left: 40%">
<h3 style="margin-left: 35%"> Please Check your email.. </h3>
<h4 style="margin-left: 38%">And confirm your identity</h4>
</div>
</div>