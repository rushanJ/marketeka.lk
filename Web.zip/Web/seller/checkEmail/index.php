<?php
session_start();

include "../CommenLayouts/header.php";
include "../CommenLayouts/slideDrawer.php";
?>

<?php


include "title.php";
include "info.php";
include "viewItems.php";

?>

<?php
include "../CommenLayouts/footer.php";
?>

