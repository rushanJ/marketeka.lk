
<?php
include "../CommenLayouts/loginheader.php";
// include "../CommenLayouts/slideDrawer.php";
?>

<?php

include "../login/register.php";

?>

<?php
include "../CommenLayouts/footer.php";
?>

