<div class="w3-row-padding w3-margin-bottom ">

    <div class="w3-quarter">
      <div class="w3-container w3-red w3-padding-16 w3-panel w3-border w3-round-xlarge">
      <div class="w3-left"><i class="fa fa-items w3-xxxlarge"></i></div>
      <div class="w3-right">
          <h3>52</h3>
        </div>
        <div class="w3-clear"></div>
        <h4><a>Items</a></h4>
      </div>
    </div>

    <div class="w3-quarter">
      <div class="w3-container w3-blue w3-padding-16 w3-panel w3-border w3-round-xlarge">
        <div class="w3-left"><i class="fa fa-users w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3>99</h3>
        </div>
        <div class="w3-clear"></div>
        <h4>Customers</h4>
      </div>
    </div>

    <div class="w3-quarter">
      <div class="w3-container w3-teal w3-padding-16 w3-panel w3-border w3-round-xlarge">
        <div class="w3-left "><i class="fa fa-bell w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3>23</h3>
        </div>
        <div class="w3-clear"></div>
        <h4>New Orders</h4>
      </div>
    </div>

    <div class="w3-quarter">
      <div class="w3-container w3-orange w3-text-white w3-padding-16 w3-panel w3-border w3-round-xlarge">
        <div class="w3-left"><i class="fa fa-history w3-xxxlarge"></i></div>
        <div class="w3-right">
          <h3>50</h3>
        </div>
        <div class="w3-clear"></div>
        <h4>Shipped Orders</h4>
      </div>
    </div>

  </div>