<?php
include "../CommenLayouts/loginheader.php";
// include "../CommenLayouts/slideDrawer.php";
?>

<?php

include "../login/index.php";

?>

<?php
include "../CommenLayouts/footer.php";
?>

