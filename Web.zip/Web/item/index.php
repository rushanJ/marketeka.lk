<?php

 include "../CommenLayouts/header.php";

 include "../CommenLayouts/navBar.php";

 include "../CommenLayouts/sideDrawer.php";

 //include "../CommenLayouts/banner.php";

 include "../CommenLayouts/sideDrawerEnd.php";

 //include "../CommenLayouts/adPanel.php";

?>


		<div class="w3l_banner_nav_right">
			
		<?php

		include "../php/viewItem.php"
		?>
		</div>
		<div class="clearfix"></div>
	</div>
<!-- //banner -->



<?php

include "../CommenLayouts/footer.php";
?>